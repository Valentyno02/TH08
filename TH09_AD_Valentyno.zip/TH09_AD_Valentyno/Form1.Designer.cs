﻿namespace TH09_AD_Valentyno
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            menuStrip1 = new MenuStrip();
            topWearToolStripMenuItem = new ToolStripMenuItem();
            kaosToolStripMenuItem = new ToolStripMenuItem();
            kemejaToolStripMenuItem = new ToolStripMenuItem();
            bottomWearToolStripMenuItem = new ToolStripMenuItem();
            celanaPanjangToolStripMenuItem = new ToolStripMenuItem();
            celanaPendekToolStripMenuItem = new ToolStripMenuItem();
            accessoriesToolStripMenuItem = new ToolStripMenuItem();
            sepatuToolStripMenuItem = new ToolStripMenuItem();
            perhiasanToolStripMenuItem = new ToolStripMenuItem();
            othersToolStripMenuItem = new ToolStripMenuItem();
            panel_others = new Panel();
            label3 = new Label();
            label2 = new Label();
            pictureBox = new PictureBox();
            bt_Add = new Button();
            tb_ItemPrice = new TextBox();
            tb_ItemName = new TextBox();
            bt_Upload = new Button();
            label1 = new Label();
            dgv_item = new DataGridView();
            label4 = new Label();
            label5 = new Label();
            panel_Kaos = new Panel();
            label11 = new Label();
            label10 = new Label();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            bt_kaos = new Button();
            bt_tanktop = new Button();
            pictureBox4 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox2 = new PictureBox();
            bt_rainbow = new Button();
            panel_Kemeja = new Panel();
            label24 = new Label();
            label25 = new Label();
            label26 = new Label();
            label27 = new Label();
            label28 = new Label();
            label29 = new Label();
            bt_kemejatosca = new Button();
            bt_kemejamerah = new Button();
            pictureBox11 = new PictureBox();
            pictureBox12 = new PictureBox();
            pictureBox13 = new PictureBox();
            bt_kemejaabu = new Button();
            panel_CelanaPjg = new Panel();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            label16 = new Label();
            label17 = new Label();
            bt_ClanaMerah = new Button();
            bt_clanaCream = new Button();
            pictureBox5 = new PictureBox();
            pictureBox6 = new PictureBox();
            pictureBox7 = new PictureBox();
            bt_clanaAbu = new Button();
            panel_sepatu = new Panel();
            label36 = new Label();
            label37 = new Label();
            label38 = new Label();
            label39 = new Label();
            label40 = new Label();
            label41 = new Label();
            bt_sandal = new Button();
            bt_sepatuhtm = new Button();
            pictureBox17 = new PictureBox();
            pictureBox18 = new PictureBox();
            pictureBox19 = new PictureBox();
            bt_sepatupth = new Button();
            panel_Celpen = new Panel();
            label18 = new Label();
            label19 = new Label();
            label20 = new Label();
            label21 = new Label();
            label22 = new Label();
            label23 = new Label();
            bt_clanaAnak = new Button();
            bt_clnaCowo = new Button();
            pictureBox8 = new PictureBox();
            pictureBox9 = new PictureBox();
            pictureBox10 = new PictureBox();
            bt_clanaCewe = new Button();
            panel_Emas = new Panel();
            label30 = new Label();
            label31 = new Label();
            label32 = new Label();
            label33 = new Label();
            label34 = new Label();
            label35 = new Label();
            bt_kalungemas = new Button();
            bt_cicinemas = new Button();
            pictureBox14 = new PictureBox();
            pictureBox15 = new PictureBox();
            pictureBox16 = new PictureBox();
            bt_cicinsilver = new Button();
            tb_subtotal = new TextBox();
            tb_total = new TextBox();
            bt_Delete = new Button();
            menuStrip1.SuspendLayout();
            panel_others.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgv_item).BeginInit();
            panel_Kaos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel_Kemeja.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).BeginInit();
            panel_CelanaPjg.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            panel_sepatu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox17).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox18).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox19).BeginInit();
            panel_Celpen.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            panel_Emas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox15).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox16).BeginInit();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { topWearToolStripMenuItem, bottomWearToolStripMenuItem, accessoriesToolStripMenuItem, othersToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Padding = new Padding(5, 2, 0, 2);
            menuStrip1.Size = new Size(938, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // topWearToolStripMenuItem
            // 
            topWearToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { kaosToolStripMenuItem, kemejaToolStripMenuItem });
            topWearToolStripMenuItem.Name = "topWearToolStripMenuItem";
            topWearToolStripMenuItem.Size = new Size(68, 20);
            topWearToolStripMenuItem.Text = "Top Wear";
            // 
            // kaosToolStripMenuItem
            // 
            kaosToolStripMenuItem.Name = "kaosToolStripMenuItem";
            kaosToolStripMenuItem.Size = new Size(109, 22);
            kaosToolStripMenuItem.Text = "T-Shirt";
            kaosToolStripMenuItem.Click += kaosToolStripMenuItem_Click;
            // 
            // kemejaToolStripMenuItem
            // 
            kemejaToolStripMenuItem.Name = "kemejaToolStripMenuItem";
            kemejaToolStripMenuItem.Size = new Size(109, 22);
            kemejaToolStripMenuItem.Text = "Shirt";
            kemejaToolStripMenuItem.Click += kemejaToolStripMenuItem_Click;
            // 
            // bottomWearToolStripMenuItem
            // 
            bottomWearToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { celanaPanjangToolStripMenuItem, celanaPendekToolStripMenuItem });
            bottomWearToolStripMenuItem.Name = "bottomWearToolStripMenuItem";
            bottomWearToolStripMenuItem.Size = new Size(89, 20);
            bottomWearToolStripMenuItem.Text = "Bottom Wear";
            // 
            // celanaPanjangToolStripMenuItem
            // 
            celanaPanjangToolStripMenuItem.Name = "celanaPanjangToolStripMenuItem";
            celanaPanjangToolStripMenuItem.Size = new Size(133, 22);
            celanaPanjangToolStripMenuItem.Text = "Pants";
            celanaPanjangToolStripMenuItem.Click += celanaPanjangToolStripMenuItem_Click;
            // 
            // celanaPendekToolStripMenuItem
            // 
            celanaPendekToolStripMenuItem.Name = "celanaPendekToolStripMenuItem";
            celanaPendekToolStripMenuItem.Size = new Size(133, 22);
            celanaPendekToolStripMenuItem.Text = "Long Pants";
            celanaPendekToolStripMenuItem.Click += celanaPendekToolStripMenuItem_Click;
            // 
            // accessoriesToolStripMenuItem
            // 
            accessoriesToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { sepatuToolStripMenuItem, perhiasanToolStripMenuItem });
            accessoriesToolStripMenuItem.Name = "accessoriesToolStripMenuItem";
            accessoriesToolStripMenuItem.Size = new Size(80, 20);
            accessoriesToolStripMenuItem.Text = "Accessories";
            // 
            // sepatuToolStripMenuItem
            // 
            sepatuToolStripMenuItem.Name = "sepatuToolStripMenuItem";
            sepatuToolStripMenuItem.Size = new Size(129, 22);
            sepatuToolStripMenuItem.Text = "Shoes";
            sepatuToolStripMenuItem.Click += sepatuToolStripMenuItem_Click;
            // 
            // perhiasanToolStripMenuItem
            // 
            perhiasanToolStripMenuItem.Name = "perhiasanToolStripMenuItem";
            perhiasanToolStripMenuItem.Size = new Size(129, 22);
            perhiasanToolStripMenuItem.Text = "Jewelleries";
            perhiasanToolStripMenuItem.Click += perhiasanToolStripMenuItem_Click;
            // 
            // othersToolStripMenuItem
            // 
            othersToolStripMenuItem.Name = "othersToolStripMenuItem";
            othersToolStripMenuItem.Size = new Size(54, 20);
            othersToolStripMenuItem.Text = "Others";
            othersToolStripMenuItem.Click += othersToolStripMenuItem_Click;
            // 
            // panel_others
            // 
            panel_others.Controls.Add(label3);
            panel_others.Controls.Add(label2);
            panel_others.Controls.Add(pictureBox);
            panel_others.Controls.Add(bt_Add);
            panel_others.Controls.Add(tb_ItemPrice);
            panel_others.Controls.Add(tb_ItemName);
            panel_others.Controls.Add(bt_Upload);
            panel_others.Controls.Add(label1);
            panel_others.Location = new Point(12, 37);
            panel_others.Margin = new Padding(3, 2, 3, 2);
            panel_others.Name = "panel_others";
            panel_others.Size = new Size(340, 218);
            panel_others.TabIndex = 1;
            panel_others.Visible = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(211, 98);
            label3.Name = "label3";
            label3.Size = new Size(60, 15);
            label3.TabIndex = 8;
            label3.Text = "Item Price";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(211, 44);
            label2.Name = "label2";
            label2.Size = new Size(66, 15);
            label2.TabIndex = 7;
            label2.Text = "Item Name";
            // 
            // pictureBox
            // 
            pictureBox.Location = new Point(21, 50);
            pictureBox.Margin = new Padding(3, 2, 3, 2);
            pictureBox.Name = "pictureBox";
            pictureBox.Size = new Size(133, 150);
            pictureBox.TabIndex = 6;
            pictureBox.TabStop = false;
            // 
            // bt_Add
            // 
            bt_Add.Location = new Point(211, 166);
            bt_Add.Margin = new Padding(3, 2, 3, 2);
            bt_Add.Name = "bt_Add";
            bt_Add.Size = new Size(102, 22);
            bt_Add.TabIndex = 5;
            bt_Add.Text = "Add To Cart";
            bt_Add.UseVisualStyleBackColor = true;
            bt_Add.Click += bt_Add_Click;
            // 
            // tb_ItemPrice
            // 
            tb_ItemPrice.Location = new Point(211, 115);
            tb_ItemPrice.Margin = new Padding(3, 2, 3, 2);
            tb_ItemPrice.Name = "tb_ItemPrice";
            tb_ItemPrice.Size = new Size(110, 23);
            tb_ItemPrice.TabIndex = 3;
            tb_ItemPrice.KeyPress += tb_ItemPrice_KeyPress;
            // 
            // tb_ItemName
            // 
            tb_ItemName.Location = new Point(211, 61);
            tb_ItemName.Margin = new Padding(3, 2, 3, 2);
            tb_ItemName.Name = "tb_ItemName";
            tb_ItemName.Size = new Size(110, 23);
            tb_ItemName.TabIndex = 2;
            // 
            // bt_Upload
            // 
            bt_Upload.Location = new Point(223, 14);
            bt_Upload.Margin = new Padding(3, 2, 3, 2);
            bt_Upload.Name = "bt_Upload";
            bt_Upload.Size = new Size(82, 22);
            bt_Upload.TabIndex = 1;
            bt_Upload.Text = "Upload";
            bt_Upload.UseVisualStyleBackColor = true;
            bt_Upload.Click += bt_Upload_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(64, 16);
            label1.Name = "label1";
            label1.Size = new Size(98, 15);
            label1.TabIndex = 0;
            label1.Text = "UPLOAD IMAGES";
            // 
            // dgv_item
            // 
            dgv_item.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_item.Location = new Point(379, 34);
            dgv_item.Margin = new Padding(3, 2, 3, 2);
            dgv_item.Name = "dgv_item";
            dgv_item.RowHeadersWidth = 51;
            dgv_item.RowTemplate.Height = 29;
            dgv_item.Size = new Size(523, 218);
            dgv_item.TabIndex = 2;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(373, 260);
            label4.Name = "label4";
            label4.Size = new Size(57, 15);
            label4.TabIndex = 3;
            label4.Text = "Sub-Total";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(373, 290);
            label5.Name = "label5";
            label5.Size = new Size(39, 15);
            label5.TabIndex = 4;
            label5.Text = "TOTAL";
            // 
            // panel_Kaos
            // 
            panel_Kaos.Controls.Add(label11);
            panel_Kaos.Controls.Add(label10);
            panel_Kaos.Controls.Add(label9);
            panel_Kaos.Controls.Add(label8);
            panel_Kaos.Controls.Add(label7);
            panel_Kaos.Controls.Add(label6);
            panel_Kaos.Controls.Add(bt_kaos);
            panel_Kaos.Controls.Add(bt_tanktop);
            panel_Kaos.Controls.Add(pictureBox4);
            panel_Kaos.Controls.Add(pictureBox3);
            panel_Kaos.Controls.Add(pictureBox2);
            panel_Kaos.Controls.Add(bt_rainbow);
            panel_Kaos.Location = new Point(12, 37);
            panel_Kaos.Margin = new Padding(3, 2, 3, 2);
            panel_Kaos.Name = "panel_Kaos";
            panel_Kaos.Size = new Size(340, 218);
            panel_Kaos.TabIndex = 9;
            panel_Kaos.Visible = false;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = SystemColors.ControlLightLight;
            label11.Location = new Point(248, 141);
            label11.Name = "label11";
            label11.Size = new Size(57, 15);
            label11.TabIndex = 15;
            label11.Text = "Rp.50.000";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = SystemColors.ControlLightLight;
            label10.Location = new Point(140, 142);
            label10.Name = "label10";
            label10.Size = new Size(57, 15);
            label10.TabIndex = 14;
            label10.Text = "Rp 30.000";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BorderStyle = BorderStyle.Fixed3D;
            label9.Location = new Point(26, 141);
            label9.Name = "label9";
            label9.Size = new Size(59, 17);
            label9.TabIndex = 13;
            label9.Text = "Rp 20.000";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = SystemColors.ControlLightLight;
            label8.BorderStyle = BorderStyle.Fixed3D;
            label8.Location = new Point(248, 126);
            label8.Name = "label8";
            label8.Size = new Size(34, 17);
            label8.TabIndex = 12;
            label8.Text = "Kaos";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = SystemColors.ControlLightLight;
            label7.Location = new Point(140, 126);
            label7.Name = "label7";
            label7.Size = new Size(53, 15);
            label7.TabIndex = 11;
            label7.Text = "Tank Top";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(14, 126);
            label6.Name = "label6";
            label6.Size = new Size(91, 15);
            label6.TabIndex = 9;
            label6.Text = "Rainbow T-Shirt";
            // 
            // bt_kaos
            // 
            bt_kaos.Location = new Point(248, 178);
            bt_kaos.Margin = new Padding(3, 2, 3, 2);
            bt_kaos.Name = "bt_kaos";
            bt_kaos.Size = new Size(71, 38);
            bt_kaos.TabIndex = 10;
            bt_kaos.Text = "Add To Cart";
            bt_kaos.UseVisualStyleBackColor = true;
            bt_kaos.Click += bt_kaos_Click;
            // 
            // bt_tanktop
            // 
            bt_tanktop.Location = new Point(140, 178);
            bt_tanktop.Margin = new Padding(3, 2, 3, 2);
            bt_tanktop.Name = "bt_tanktop";
            bt_tanktop.Size = new Size(71, 38);
            bt_tanktop.TabIndex = 9;
            bt_tanktop.Text = "Add To Cart";
            bt_tanktop.UseVisualStyleBackColor = true;
            bt_tanktop.Click += bt_tanktop_Click;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(228, 14);
            pictureBox4.Margin = new Padding(3, 2, 3, 2);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(102, 110);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 8;
            pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(120, 14);
            pictureBox3.Margin = new Padding(3, 2, 3, 2);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(102, 110);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 7;
            pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(12, 14);
            pictureBox2.Margin = new Padding(3, 2, 3, 2);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(102, 110);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 6;
            pictureBox2.TabStop = false;
            // 
            // bt_rainbow
            // 
            bt_rainbow.Location = new Point(26, 178);
            bt_rainbow.Margin = new Padding(3, 2, 3, 2);
            bt_rainbow.Name = "bt_rainbow";
            bt_rainbow.Size = new Size(71, 38);
            bt_rainbow.TabIndex = 5;
            bt_rainbow.Text = "Add To Cart";
            bt_rainbow.UseVisualStyleBackColor = true;
            bt_rainbow.Click += bt_rainbow_Click;
            // 
            // panel_Kemeja
            // 
            panel_Kemeja.Controls.Add(label24);
            panel_Kemeja.Controls.Add(label25);
            panel_Kemeja.Controls.Add(label26);
            panel_Kemeja.Controls.Add(label27);
            panel_Kemeja.Controls.Add(label28);
            panel_Kemeja.Controls.Add(label29);
            panel_Kemeja.Controls.Add(bt_kemejatosca);
            panel_Kemeja.Controls.Add(bt_kemejamerah);
            panel_Kemeja.Controls.Add(pictureBox11);
            panel_Kemeja.Controls.Add(pictureBox12);
            panel_Kemeja.Controls.Add(pictureBox13);
            panel_Kemeja.Controls.Add(bt_kemejaabu);
            panel_Kemeja.Location = new Point(12, 37);
            panel_Kemeja.Margin = new Padding(3, 2, 3, 2);
            panel_Kemeja.Name = "panel_Kemeja";
            panel_Kemeja.Size = new Size(340, 218);
            panel_Kemeja.TabIndex = 18;
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.BackColor = SystemColors.ControlLightLight;
            label24.Location = new Point(248, 141);
            label24.Name = "label24";
            label24.Size = new Size(57, 15);
            label24.TabIndex = 15;
            label24.Text = "Rp.50.000";
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.BackColor = SystemColors.ControlLightLight;
            label25.Location = new Point(140, 142);
            label25.Name = "label25";
            label25.Size = new Size(57, 15);
            label25.TabIndex = 14;
            label25.Text = "Rp 30.000";
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.BorderStyle = BorderStyle.Fixed3D;
            label26.Location = new Point(26, 141);
            label26.Name = "label26";
            label26.Size = new Size(59, 17);
            label26.TabIndex = 13;
            label26.Text = "Rp 20.000";
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.BackColor = SystemColors.ControlLightLight;
            label27.Location = new Point(248, 126);
            label27.Name = "label27";
            label27.Size = new Size(78, 15);
            label27.TabIndex = 12;
            label27.Text = "Kemeja Tosca";
            // 
            // label28
            // 
            label28.AutoSize = true;
            label28.BackColor = SystemColors.ControlLightLight;
            label28.Location = new Point(140, 126);
            label28.Name = "label28";
            label28.Size = new Size(83, 15);
            label28.TabIndex = 11;
            label28.Text = "Kemeja Merah";
            // 
            // label29
            // 
            label29.AutoSize = true;
            label29.Location = new Point(14, 126);
            label29.Name = "label29";
            label29.Size = new Size(71, 15);
            label29.TabIndex = 9;
            label29.Text = "Kemeja Abu";
            // 
            // bt_kemejatosca
            // 
            bt_kemejatosca.Location = new Point(248, 178);
            bt_kemejatosca.Margin = new Padding(3, 2, 3, 2);
            bt_kemejatosca.Name = "bt_kemejatosca";
            bt_kemejatosca.Size = new Size(71, 38);
            bt_kemejatosca.TabIndex = 10;
            bt_kemejatosca.Text = "Add To Cart";
            bt_kemejatosca.UseVisualStyleBackColor = true;
            bt_kemejatosca.Click += bt_kemejatosca_Click;
            // 
            // bt_kemejamerah
            // 
            bt_kemejamerah.Location = new Point(140, 178);
            bt_kemejamerah.Margin = new Padding(3, 2, 3, 2);
            bt_kemejamerah.Name = "bt_kemejamerah";
            bt_kemejamerah.Size = new Size(71, 38);
            bt_kemejamerah.TabIndex = 9;
            bt_kemejamerah.Text = "Add To Cart";
            bt_kemejamerah.UseVisualStyleBackColor = true;
            bt_kemejamerah.Click += bt_kemejamerah_Click;
            // 
            // pictureBox11
            // 
            pictureBox11.Image = (Image)resources.GetObject("pictureBox11.Image");
            pictureBox11.Location = new Point(228, 14);
            pictureBox11.Margin = new Padding(3, 2, 3, 2);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(102, 110);
            pictureBox11.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox11.TabIndex = 8;
            pictureBox11.TabStop = false;
            // 
            // pictureBox12
            // 
            pictureBox12.Image = (Image)resources.GetObject("pictureBox12.Image");
            pictureBox12.Location = new Point(120, 14);
            pictureBox12.Margin = new Padding(3, 2, 3, 2);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new Size(102, 110);
            pictureBox12.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox12.TabIndex = 7;
            pictureBox12.TabStop = false;
            // 
            // pictureBox13
            // 
            pictureBox13.Image = (Image)resources.GetObject("pictureBox13.Image");
            pictureBox13.Location = new Point(11, 14);
            pictureBox13.Margin = new Padding(3, 2, 3, 2);
            pictureBox13.Name = "pictureBox13";
            pictureBox13.Size = new Size(102, 110);
            pictureBox13.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBox13.TabIndex = 6;
            pictureBox13.TabStop = false;
            // 
            // bt_kemejaabu
            // 
            bt_kemejaabu.Location = new Point(26, 178);
            bt_kemejaabu.Margin = new Padding(3, 2, 3, 2);
            bt_kemejaabu.Name = "bt_kemejaabu";
            bt_kemejaabu.Size = new Size(71, 38);
            bt_kemejaabu.TabIndex = 5;
            bt_kemejaabu.Text = "Add To Cart";
            bt_kemejaabu.UseVisualStyleBackColor = true;
            bt_kemejaabu.Click += bt_kemejaabu_Click;
            // 
            // panel_CelanaPjg
            // 
            panel_CelanaPjg.Controls.Add(label12);
            panel_CelanaPjg.Controls.Add(label13);
            panel_CelanaPjg.Controls.Add(label14);
            panel_CelanaPjg.Controls.Add(label15);
            panel_CelanaPjg.Controls.Add(label16);
            panel_CelanaPjg.Controls.Add(label17);
            panel_CelanaPjg.Controls.Add(bt_ClanaMerah);
            panel_CelanaPjg.Controls.Add(bt_clanaCream);
            panel_CelanaPjg.Controls.Add(pictureBox5);
            panel_CelanaPjg.Controls.Add(pictureBox6);
            panel_CelanaPjg.Controls.Add(pictureBox7);
            panel_CelanaPjg.Controls.Add(bt_clanaAbu);
            panel_CelanaPjg.Location = new Point(12, 37);
            panel_CelanaPjg.Margin = new Padding(3, 2, 3, 2);
            panel_CelanaPjg.Name = "panel_CelanaPjg";
            panel_CelanaPjg.Size = new Size(340, 218);
            panel_CelanaPjg.TabIndex = 16;
            panel_CelanaPjg.Visible = false;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = SystemColors.ControlLightLight;
            label12.Location = new Point(248, 141);
            label12.Name = "label12";
            label12.Size = new Size(57, 15);
            label12.TabIndex = 15;
            label12.Text = "Rp.50.000";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = SystemColors.ControlLightLight;
            label13.Location = new Point(140, 142);
            label13.Name = "label13";
            label13.Size = new Size(57, 15);
            label13.TabIndex = 14;
            label13.Text = "Rp 30.000";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.BorderStyle = BorderStyle.Fixed3D;
            label14.Location = new Point(26, 141);
            label14.Name = "label14";
            label14.Size = new Size(59, 17);
            label14.TabIndex = 13;
            label14.Text = "Rp 20.000";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.BackColor = SystemColors.ControlLightLight;
            label15.Location = new Point(248, 126);
            label15.Name = "label15";
            label15.Size = new Size(80, 15);
            label15.TabIndex = 12;
            label15.Text = "Celana Merah";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.BackColor = SystemColors.ControlLightLight;
            label16.Location = new Point(140, 126);
            label16.Name = "label16";
            label16.Size = new Size(81, 15);
            label16.TabIndex = 11;
            label16.Text = "Celana Cream";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(14, 126);
            label17.Name = "label17";
            label17.Size = new Size(68, 15);
            label17.TabIndex = 9;
            label17.Text = "Celana Abu";
            // 
            // bt_ClanaMerah
            // 
            bt_ClanaMerah.Location = new Point(248, 178);
            bt_ClanaMerah.Margin = new Padding(3, 2, 3, 2);
            bt_ClanaMerah.Name = "bt_ClanaMerah";
            bt_ClanaMerah.Size = new Size(71, 38);
            bt_ClanaMerah.TabIndex = 10;
            bt_ClanaMerah.Text = "Add To Cart";
            bt_ClanaMerah.UseVisualStyleBackColor = true;
            bt_ClanaMerah.Click += bt_ClanaMerah_Click;
            // 
            // bt_clanaCream
            // 
            bt_clanaCream.Location = new Point(140, 178);
            bt_clanaCream.Margin = new Padding(3, 2, 3, 2);
            bt_clanaCream.Name = "bt_clanaCream";
            bt_clanaCream.Size = new Size(71, 38);
            bt_clanaCream.TabIndex = 9;
            bt_clanaCream.Text = "Add To Cart";
            bt_clanaCream.UseVisualStyleBackColor = true;
            bt_clanaCream.Click += bt_clanaCream_Click;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(228, 14);
            pictureBox5.Margin = new Padding(3, 2, 3, 2);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(102, 110);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 8;
            pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(120, 14);
            pictureBox6.Margin = new Padding(3, 2, 3, 2);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(102, 110);
            pictureBox6.TabIndex = 7;
            pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(11, 14);
            pictureBox7.Margin = new Padding(3, 2, 3, 2);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(102, 110);
            pictureBox7.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox7.TabIndex = 6;
            pictureBox7.TabStop = false;
            // 
            // bt_clanaAbu
            // 
            bt_clanaAbu.Location = new Point(26, 178);
            bt_clanaAbu.Margin = new Padding(3, 2, 3, 2);
            bt_clanaAbu.Name = "bt_clanaAbu";
            bt_clanaAbu.Size = new Size(71, 38);
            bt_clanaAbu.TabIndex = 5;
            bt_clanaAbu.Text = "Add To Cart";
            bt_clanaAbu.UseVisualStyleBackColor = true;
            bt_clanaAbu.Click += bt_clanaAbu_Click;
            // 
            // panel_sepatu
            // 
            panel_sepatu.Controls.Add(label36);
            panel_sepatu.Controls.Add(label37);
            panel_sepatu.Controls.Add(label38);
            panel_sepatu.Controls.Add(label39);
            panel_sepatu.Controls.Add(label40);
            panel_sepatu.Controls.Add(label41);
            panel_sepatu.Controls.Add(bt_sandal);
            panel_sepatu.Controls.Add(bt_sepatuhtm);
            panel_sepatu.Controls.Add(pictureBox17);
            panel_sepatu.Controls.Add(pictureBox18);
            panel_sepatu.Controls.Add(pictureBox19);
            panel_sepatu.Controls.Add(bt_sepatupth);
            panel_sepatu.Location = new Point(12, 37);
            panel_sepatu.Margin = new Padding(3, 2, 3, 2);
            panel_sepatu.Name = "panel_sepatu";
            panel_sepatu.Size = new Size(340, 218);
            panel_sepatu.TabIndex = 20;
            panel_sepatu.Visible = false;
            // 
            // label36
            // 
            label36.AutoSize = true;
            label36.BackColor = SystemColors.ControlLightLight;
            label36.Location = new Point(248, 141);
            label36.Name = "label36";
            label36.Size = new Size(57, 15);
            label36.TabIndex = 15;
            label36.Text = "Rp.50.000";
            // 
            // label37
            // 
            label37.AutoSize = true;
            label37.BackColor = SystemColors.ControlLightLight;
            label37.Location = new Point(140, 142);
            label37.Name = "label37";
            label37.Size = new Size(57, 15);
            label37.TabIndex = 14;
            label37.Text = "Rp 30.000";
            // 
            // label38
            // 
            label38.AutoSize = true;
            label38.BorderStyle = BorderStyle.Fixed3D;
            label38.Location = new Point(26, 141);
            label38.Name = "label38";
            label38.Size = new Size(59, 17);
            label38.TabIndex = 13;
            label38.Text = "Rp 20.000";
            // 
            // label39
            // 
            label39.AutoSize = true;
            label39.BackColor = SystemColors.ControlLightLight;
            label39.Location = new Point(248, 126);
            label39.Name = "label39";
            label39.Size = new Size(42, 15);
            label39.TabIndex = 12;
            label39.Text = "Sandal";
            // 
            // label40
            // 
            label40.AutoSize = true;
            label40.BackColor = SystemColors.ControlLightLight;
            label40.Location = new Point(134, 126);
            label40.Name = "label40";
            label40.Size = new Size(79, 15);
            label40.TabIndex = 11;
            label40.Text = "Sepatu Hitam";
            // 
            // label41
            // 
            label41.AutoSize = true;
            label41.Location = new Point(21, 126);
            label41.Name = "label41";
            label41.Size = new Size(74, 15);
            label41.TabIndex = 9;
            label41.Text = "Sepatu Putih";
            // 
            // bt_sandal
            // 
            bt_sandal.Location = new Point(248, 178);
            bt_sandal.Margin = new Padding(3, 2, 3, 2);
            bt_sandal.Name = "bt_sandal";
            bt_sandal.Size = new Size(71, 38);
            bt_sandal.TabIndex = 10;
            bt_sandal.Text = "Add To Cart";
            bt_sandal.UseVisualStyleBackColor = true;
            bt_sandal.Click += bt_sandal_Click;
            // 
            // bt_sepatuhtm
            // 
            bt_sepatuhtm.Location = new Point(140, 178);
            bt_sepatuhtm.Margin = new Padding(3, 2, 3, 2);
            bt_sepatuhtm.Name = "bt_sepatuhtm";
            bt_sepatuhtm.Size = new Size(71, 38);
            bt_sepatuhtm.TabIndex = 9;
            bt_sepatuhtm.Text = "Add To Cart";
            bt_sepatuhtm.UseVisualStyleBackColor = true;
            bt_sepatuhtm.Click += bt_sepatuhtm_Click;
            // 
            // pictureBox17
            // 
            pictureBox17.Image = (Image)resources.GetObject("pictureBox17.Image");
            pictureBox17.Location = new Point(228, 14);
            pictureBox17.Margin = new Padding(3, 2, 3, 2);
            pictureBox17.Name = "pictureBox17";
            pictureBox17.Size = new Size(102, 110);
            pictureBox17.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox17.TabIndex = 8;
            pictureBox17.TabStop = false;
            // 
            // pictureBox18
            // 
            pictureBox18.Image = (Image)resources.GetObject("pictureBox18.Image");
            pictureBox18.Location = new Point(120, 14);
            pictureBox18.Margin = new Padding(3, 2, 3, 2);
            pictureBox18.Name = "pictureBox18";
            pictureBox18.Size = new Size(102, 110);
            pictureBox18.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox18.TabIndex = 7;
            pictureBox18.TabStop = false;
            // 
            // pictureBox19
            // 
            pictureBox19.Image = (Image)resources.GetObject("pictureBox19.Image");
            pictureBox19.Location = new Point(11, 14);
            pictureBox19.Margin = new Padding(3, 2, 3, 2);
            pictureBox19.Name = "pictureBox19";
            pictureBox19.Size = new Size(102, 110);
            pictureBox19.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBox19.TabIndex = 6;
            pictureBox19.TabStop = false;
            // 
            // bt_sepatupth
            // 
            bt_sepatupth.Location = new Point(26, 178);
            bt_sepatupth.Margin = new Padding(3, 2, 3, 2);
            bt_sepatupth.Name = "bt_sepatupth";
            bt_sepatupth.Size = new Size(71, 38);
            bt_sepatupth.TabIndex = 5;
            bt_sepatupth.Text = "Add To Cart";
            bt_sepatupth.UseVisualStyleBackColor = true;
            bt_sepatupth.Click += bt_sepatupth_Click;
            // 
            // panel_Celpen
            // 
            panel_Celpen.Controls.Add(label18);
            panel_Celpen.Controls.Add(label19);
            panel_Celpen.Controls.Add(label20);
            panel_Celpen.Controls.Add(label21);
            panel_Celpen.Controls.Add(label22);
            panel_Celpen.Controls.Add(label23);
            panel_Celpen.Controls.Add(bt_clanaAnak);
            panel_Celpen.Controls.Add(bt_clnaCowo);
            panel_Celpen.Controls.Add(pictureBox8);
            panel_Celpen.Controls.Add(pictureBox9);
            panel_Celpen.Controls.Add(pictureBox10);
            panel_Celpen.Controls.Add(bt_clanaCewe);
            panel_Celpen.Location = new Point(12, 37);
            panel_Celpen.Margin = new Padding(3, 2, 3, 2);
            panel_Celpen.Name = "panel_Celpen";
            panel_Celpen.Size = new Size(340, 218);
            panel_Celpen.TabIndex = 17;
            panel_Celpen.Visible = false;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.BackColor = SystemColors.ControlLightLight;
            label18.Location = new Point(248, 141);
            label18.Name = "label18";
            label18.Size = new Size(57, 15);
            label18.TabIndex = 15;
            label18.Text = "Rp.50.000";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.BackColor = SystemColors.ControlLightLight;
            label19.Location = new Point(140, 142);
            label19.Name = "label19";
            label19.Size = new Size(57, 15);
            label19.TabIndex = 14;
            label19.Text = "Rp 30.000";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.BorderStyle = BorderStyle.Fixed3D;
            label20.Location = new Point(26, 141);
            label20.Name = "label20";
            label20.Size = new Size(59, 17);
            label20.TabIndex = 13;
            label20.Text = "Rp 20.000";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.BackColor = SystemColors.ControlLightLight;
            label21.Location = new Point(248, 126);
            label21.Name = "label21";
            label21.Size = new Size(73, 15);
            label21.TabIndex = 12;
            label21.Text = "Celana Anak";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.BackColor = SystemColors.ControlLightLight;
            label22.Location = new Point(140, 126);
            label22.Name = "label22";
            label22.Size = new Size(75, 15);
            label22.TabIndex = 11;
            label22.Text = "Celana cowo";
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Location = new Point(14, 126);
            label23.Name = "label23";
            label23.Size = new Size(75, 15);
            label23.TabIndex = 9;
            label23.Text = "Celana Cewe";
            // 
            // bt_clanaAnak
            // 
            bt_clanaAnak.Location = new Point(248, 178);
            bt_clanaAnak.Margin = new Padding(3, 2, 3, 2);
            bt_clanaAnak.Name = "bt_clanaAnak";
            bt_clanaAnak.Size = new Size(71, 38);
            bt_clanaAnak.TabIndex = 10;
            bt_clanaAnak.Text = "Add To Cart";
            bt_clanaAnak.UseVisualStyleBackColor = true;
            bt_clanaAnak.Click += bt_clanaAnak_Click;
            // 
            // bt_clnaCowo
            // 
            bt_clnaCowo.Location = new Point(140, 178);
            bt_clnaCowo.Margin = new Padding(3, 2, 3, 2);
            bt_clnaCowo.Name = "bt_clnaCowo";
            bt_clnaCowo.Size = new Size(71, 38);
            bt_clnaCowo.TabIndex = 9;
            bt_clnaCowo.Text = "Add To Cart";
            bt_clnaCowo.UseVisualStyleBackColor = true;
            bt_clnaCowo.Click += bt_clnaCowo_Click;
            // 
            // pictureBox8
            // 
            pictureBox8.Image = (Image)resources.GetObject("pictureBox8.Image");
            pictureBox8.Location = new Point(228, 14);
            pictureBox8.Margin = new Padding(3, 2, 3, 2);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(102, 110);
            pictureBox8.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox8.TabIndex = 8;
            pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            pictureBox9.Image = (Image)resources.GetObject("pictureBox9.Image");
            pictureBox9.Location = new Point(120, 14);
            pictureBox9.Margin = new Padding(3, 2, 3, 2);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(102, 110);
            pictureBox9.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox9.TabIndex = 7;
            pictureBox9.TabStop = false;
            // 
            // pictureBox10
            // 
            pictureBox10.Image = (Image)resources.GetObject("pictureBox10.Image");
            pictureBox10.Location = new Point(11, 14);
            pictureBox10.Margin = new Padding(3, 2, 3, 2);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(102, 110);
            pictureBox10.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox10.TabIndex = 6;
            pictureBox10.TabStop = false;
            // 
            // bt_clanaCewe
            // 
            bt_clanaCewe.Location = new Point(26, 178);
            bt_clanaCewe.Margin = new Padding(3, 2, 3, 2);
            bt_clanaCewe.Name = "bt_clanaCewe";
            bt_clanaCewe.Size = new Size(71, 38);
            bt_clanaCewe.TabIndex = 5;
            bt_clanaCewe.Text = "Add To Cart";
            bt_clanaCewe.UseVisualStyleBackColor = true;
            bt_clanaCewe.Click += bt_clanaCewe_Click;
            // 
            // panel_Emas
            // 
            panel_Emas.Controls.Add(label30);
            panel_Emas.Controls.Add(label31);
            panel_Emas.Controls.Add(label32);
            panel_Emas.Controls.Add(label33);
            panel_Emas.Controls.Add(label34);
            panel_Emas.Controls.Add(label35);
            panel_Emas.Controls.Add(bt_kalungemas);
            panel_Emas.Controls.Add(bt_cicinemas);
            panel_Emas.Controls.Add(pictureBox14);
            panel_Emas.Controls.Add(pictureBox15);
            panel_Emas.Controls.Add(pictureBox16);
            panel_Emas.Controls.Add(bt_cicinsilver);
            panel_Emas.Location = new Point(12, 37);
            panel_Emas.Margin = new Padding(3, 2, 3, 2);
            panel_Emas.Name = "panel_Emas";
            panel_Emas.Size = new Size(340, 218);
            panel_Emas.TabIndex = 19;
            panel_Emas.Visible = false;
            // 
            // label30
            // 
            label30.AutoSize = true;
            label30.BackColor = SystemColors.ControlLightLight;
            label30.Location = new Point(248, 141);
            label30.Name = "label30";
            label30.Size = new Size(57, 15);
            label30.TabIndex = 15;
            label30.Text = "Rp.50.000";
            // 
            // label31
            // 
            label31.AutoSize = true;
            label31.BackColor = SystemColors.ControlLightLight;
            label31.Location = new Point(140, 142);
            label31.Name = "label31";
            label31.Size = new Size(57, 15);
            label31.TabIndex = 14;
            label31.Text = "Rp 30.000";
            // 
            // label32
            // 
            label32.AutoSize = true;
            label32.BorderStyle = BorderStyle.Fixed3D;
            label32.Location = new Point(26, 141);
            label32.Name = "label32";
            label32.Size = new Size(59, 17);
            label32.TabIndex = 13;
            label32.Text = "Rp 20.000";
            // 
            // label33
            // 
            label33.AutoSize = true;
            label33.BackColor = SystemColors.ControlLightLight;
            label33.Location = new Point(248, 126);
            label33.Name = "label33";
            label33.Size = new Size(75, 15);
            label33.TabIndex = 12;
            label33.Text = "Kalung Emas";
            // 
            // label34
            // 
            label34.AutoSize = true;
            label34.BackColor = SystemColors.ControlLightLight;
            label34.Location = new Point(134, 126);
            label34.Name = "label34";
            label34.Size = new Size(72, 15);
            label34.TabIndex = 11;
            label34.Text = "Cincin Emas";
            // 
            // label35
            // 
            label35.AutoSize = true;
            label35.Location = new Point(21, 126);
            label35.Name = "label35";
            label35.Size = new Size(71, 15);
            label35.TabIndex = 9;
            label35.Text = "Cincin silver";
            label35.Click += label35_Click;
            // 
            // bt_kalungemas
            // 
            bt_kalungemas.Location = new Point(248, 178);
            bt_kalungemas.Margin = new Padding(3, 2, 3, 2);
            bt_kalungemas.Name = "bt_kalungemas";
            bt_kalungemas.Size = new Size(71, 38);
            bt_kalungemas.TabIndex = 10;
            bt_kalungemas.Text = "Add To Cart";
            bt_kalungemas.UseVisualStyleBackColor = true;
            bt_kalungemas.Click += bt_kalungemas_Click;
            // 
            // bt_cicinemas
            // 
            bt_cicinemas.Location = new Point(140, 178);
            bt_cicinemas.Margin = new Padding(3, 2, 3, 2);
            bt_cicinemas.Name = "bt_cicinemas";
            bt_cicinemas.Size = new Size(71, 38);
            bt_cicinemas.TabIndex = 9;
            bt_cicinemas.Text = "Add To Cart";
            bt_cicinemas.UseVisualStyleBackColor = true;
            bt_cicinemas.Click += bt_cicinemas_Click;
            // 
            // pictureBox14
            // 
            pictureBox14.Image = (Image)resources.GetObject("pictureBox14.Image");
            pictureBox14.Location = new Point(228, 14);
            pictureBox14.Margin = new Padding(3, 2, 3, 2);
            pictureBox14.Name = "pictureBox14";
            pictureBox14.Size = new Size(102, 110);
            pictureBox14.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox14.TabIndex = 8;
            pictureBox14.TabStop = false;
            // 
            // pictureBox15
            // 
            pictureBox15.Image = (Image)resources.GetObject("pictureBox15.Image");
            pictureBox15.Location = new Point(120, 14);
            pictureBox15.Margin = new Padding(3, 2, 3, 2);
            pictureBox15.Name = "pictureBox15";
            pictureBox15.Size = new Size(102, 110);
            pictureBox15.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox15.TabIndex = 7;
            pictureBox15.TabStop = false;
            // 
            // pictureBox16
            // 
            pictureBox16.Image = (Image)resources.GetObject("pictureBox16.Image");
            pictureBox16.Location = new Point(11, 14);
            pictureBox16.Margin = new Padding(3, 2, 3, 2);
            pictureBox16.Name = "pictureBox16";
            pictureBox16.Size = new Size(102, 110);
            pictureBox16.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBox16.TabIndex = 6;
            pictureBox16.TabStop = false;
            // 
            // bt_cicinsilver
            // 
            bt_cicinsilver.Location = new Point(26, 178);
            bt_cicinsilver.Margin = new Padding(3, 2, 3, 2);
            bt_cicinsilver.Name = "bt_cicinsilver";
            bt_cicinsilver.Size = new Size(71, 38);
            bt_cicinsilver.TabIndex = 5;
            bt_cicinsilver.Text = "Add To Cart";
            bt_cicinsilver.UseVisualStyleBackColor = true;
            bt_cicinsilver.Click += bt_cicinsilver_Click;
            // 
            // tb_subtotal
            // 
            tb_subtotal.Location = new Point(442, 260);
            tb_subtotal.Margin = new Padding(3, 2, 3, 2);
            tb_subtotal.Name = "tb_subtotal";
            tb_subtotal.Size = new Size(116, 23);
            tb_subtotal.TabIndex = 21;
            // 
            // tb_total
            // 
            tb_total.Location = new Point(442, 287);
            tb_total.Margin = new Padding(3, 2, 3, 2);
            tb_total.Name = "tb_total";
            tb_total.Size = new Size(116, 23);
            tb_total.TabIndex = 22;
            // 
            // bt_Delete
            // 
            bt_Delete.Location = new Point(831, 269);
            bt_Delete.Margin = new Padding(3, 2, 3, 2);
            bt_Delete.Name = "bt_Delete";
            bt_Delete.Size = new Size(71, 38);
            bt_Delete.TabIndex = 16;
            bt_Delete.Text = "Delete";
            bt_Delete.UseVisualStyleBackColor = true;
            bt_Delete.Click += bt_Delete_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(938, 430);
            Controls.Add(bt_Delete);
            Controls.Add(tb_total);
            Controls.Add(tb_subtotal);
            Controls.Add(panel_Celpen);
            Controls.Add(panel_CelanaPjg);
            Controls.Add(panel_Emas);
            Controls.Add(panel_Kemeja);
            Controls.Add(panel_sepatu);
            Controls.Add(panel_Kaos);
            Controls.Add(label5);
            Controls.Add(dgv_item);
            Controls.Add(label4);
            Controls.Add(panel_others);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Margin = new Padding(3, 2, 3, 2);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            panel_others.ResumeLayout(false);
            panel_others.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgv_item).EndInit();
            panel_Kaos.ResumeLayout(false);
            panel_Kaos.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel_Kemeja.ResumeLayout(false);
            panel_Kemeja.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).EndInit();
            panel_CelanaPjg.ResumeLayout(false);
            panel_CelanaPjg.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            panel_sepatu.ResumeLayout(false);
            panel_sepatu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox17).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox18).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox19).EndInit();
            panel_Celpen.ResumeLayout(false);
            panel_Celpen.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            panel_Emas.ResumeLayout(false);
            panel_Emas.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox15).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox16).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem topWearToolStripMenuItem;
        private ToolStripMenuItem bottomWearToolStripMenuItem;
        private ToolStripMenuItem accessoriesToolStripMenuItem;
        private ToolStripMenuItem othersToolStripMenuItem;
        private Panel panel_others;
        private Label label3;
        private Label label2;
        private PictureBox pictureBox;
        private Button bt_Add;
        private TextBox tb_ItemPrice;
        private TextBox tb_ItemName;
        private Button bt_Upload;
        private Label label1;
        private DataGridView dgv_item;
        private Label label4;
        private Label label5;
        private Panel panel_Kaos;
        private PictureBox pictureBox2;
        private Button bt_rainbow;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private Button bt_kaos;
        private Button bt_tanktop;
        private PictureBox pictureBox4;
        private PictureBox pictureBox3;
        private Label label11;
        private Label label10;
        private Panel panel_CelanaPjg;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private Label label16;
        private Label label17;
        private Button bt_ClanaMerah;
        private Button bt_clanaCream;
        private PictureBox pictureBox5;
        private PictureBox pictureBox6;
        private PictureBox pictureBox7;
        private Button bt_clanaAbu;
        private Panel panel_Celpen;
        private Label label18;
        private Label label19;
        private Label label20;
        private Label label21;
        private Label label22;
        private Label label23;
        private Button bt_clanaAnak;
        private Button bt_clnaCowo;
        private PictureBox pictureBox8;
        private PictureBox pictureBox9;
        private PictureBox pictureBox10;
        private Button bt_clanaCewe;
        private Panel panel_Kemeja;
        private Label label24;
        private Label label25;
        private Label label26;
        private Label label27;
        private Label label28;
        private Label label29;
        private Button bt_kemejatosca;
        private Button bt_kemejamerah;
        private PictureBox pictureBox11;
        private PictureBox pictureBox12;
        private PictureBox pictureBox13;
        private Button bt_kemejaabu;
        private Panel panel_Emas;
        private Label label30;
        private Label label31;
        private Label label32;
        private Label label33;
        private Label label34;
        private Label label35;
        private Button bt_kalungemas;
        private Button bt_cicinemas;
        private PictureBox pictureBox14;
        private PictureBox pictureBox15;
        private PictureBox pictureBox16;
        private Button bt_cicinsilver;
        private ToolStripMenuItem kaosToolStripMenuItem;
        private ToolStripMenuItem kemejaToolStripMenuItem;
        private ToolStripMenuItem celanaPanjangToolStripMenuItem;
        private ToolStripMenuItem celanaPendekToolStripMenuItem;
        private ToolStripMenuItem sepatuToolStripMenuItem;
        private ToolStripMenuItem perhiasanToolStripMenuItem;
        private Panel panel_sepatu;
        private Label label36;
        private Label label37;
        private Label label38;
        private Label label39;
        private Label label40;
        private Label label41;
        private Button bt_sandal;
        private Button bt_sepatuhtm;
        private PictureBox pictureBox17;
        private PictureBox pictureBox18;
        private PictureBox pictureBox19;
        private Button bt_sepatupth;
        private TextBox tb_subtotal;
        private TextBox tb_total;
        private Button bt_Delete;
    }
}