using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Diagnostics.Metrics;

namespace TH09_AD_Valentyno
{
    public partial class Form1 : Form
    {
        DataTable dtBarang = new DataTable();
        int counter = 0;
        int price1 = 20000;
        int price2 = 30000;
        int price3 = 50000;
        int totals = 0;
        int totalPrice;
        int totalPrices;
        int index;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panel_Emas.Visible = false;
            panel_sepatu.Visible = false;
            panel_CelanaPjg.Visible = false;
            panel_Kaos.Visible = false;
            panel_others.Visible = false;
            panel_Kemeja.Visible = false;
            panel_Celpen.Visible = false;

            tb_ItemPrice.Enabled = false;
            tb_ItemName.Enabled = false;
            tb_subtotal.Enabled = false;
            tb_total.Enabled = false;

            dtBarang.Columns.Add("Quantity");
            dtBarang.Columns.Add("Item Name");
            dtBarang.Columns.Add("Item Price");
            dtBarang.Columns.Add("Total");

            dgv_item.DataSource = dtBarang;


        }
        private void label35_Click(object sender, EventArgs e)
        {

        }

        private void kaosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_Kaos.Visible = true;//
            panel_others.Visible = false;
            panel_Kemeja.Visible = false;
            panel_Celpen.Visible = false;
            panel_CelanaPjg.Visible = false;
            panel_Emas.Visible = false;
            panel_sepatu.Visible = false;
        }

        private void kemejaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_Kaos.Visible = false;
            panel_others.Visible = false;
            panel_Kemeja.Visible = true; //
            panel_Celpen.Visible = false;
            panel_CelanaPjg.Visible = false;
            panel_Emas.Visible = false;
            panel_sepatu.Visible = false;

        }

        private void celanaPanjangToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_CelanaPjg.Visible = true; //
            panel_Kaos.Visible = false;
            panel_others.Visible = false;
            panel_Kemeja.Visible = false;
            panel_Celpen.Visible = false;
            panel_Emas.Visible = false;
            panel_sepatu.Visible = false;
        }

        private void celanaPendekToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_Celpen.Visible = true;
            panel_CelanaPjg.Visible = false;
            panel_Kaos.Visible = false;
            panel_others.Visible = false;
            panel_Kemeja.Visible = false;
            panel_sepatu.Visible = false;
            panel_Emas.Visible = false;
        }

        private void sepatuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_sepatu.Visible = true;
            panel_CelanaPjg.Visible = false;
            panel_Kaos.Visible = false;
            panel_others.Visible = false;
            panel_Kemeja.Visible = false;
            panel_Celpen.Visible = false;
            panel_Emas.Visible = false;
        }

        private void perhiasanToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_Emas.Visible = true;
            panel_sepatu.Visible = false;
            panel_CelanaPjg.Visible = false;
            panel_Kaos.Visible = false;
            panel_others.Visible = false;
            panel_Kemeja.Visible = false;
            panel_Celpen.Visible = false;
        }

        private void othersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_others.Visible = true;
            panel_Kemeja.Visible = false;
            panel_Celpen.Visible = false;
            panel_Emas.Visible = false;
            panel_sepatu.Visible = false;
            panel_CelanaPjg.Visible = false;
            panel_Kaos.Visible = false;
        }

        private void bt_sepatupth_Click(object sender, EventArgs e)
        {
            int tax;
            bool cek = false;

            foreach (DataGridViewRow row in dgv_item.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Sepatu Putih")
                {
                    cek = true;
                    counter++;
                    int currentqty = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentqty + 1;
                    totals = Convert.ToInt32(row.Cells[0].Value) * price1;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!cek)
            {
                dtBarang.Rows.Add(1, "Sepatu Putih", "Rp 20.000", price1);
            }
            totalPrices = totalPrice += (price1);
            tax = totalPrices / 10;
            tb_subtotal.Text = totalPrices.ToString();
            tb_total.Text = (totalPrices + tax).ToString();

        }

        private void bt_sepatuhtm_Click(object sender, EventArgs e)
        {
            int tax;
            bool cek = false;

            foreach (DataGridViewRow row in dgv_item.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Sepatu Hitam")
                {
                    cek = true;
                    counter++;
                    int currentqty = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentqty + 1;
                    totals = Convert.ToInt32(row.Cells[0].Value) * price1;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!cek)
            {
                dtBarang.Rows.Add(1, "Sepatu Hitam", "Rp 30.000", price2);
            }
            totalPrices = totalPrice += (price2);
            tax = totalPrices / 10;
            tb_subtotal.Text = totalPrices.ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void bt_sandal_Click(object sender, EventArgs e)
        {
            int tax;
            bool cek = false;

            foreach (DataGridViewRow row in dgv_item.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Sandal")
                {
                    cek = true;
                    counter++;
                    int currentqty = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentqty + 1;
                    totals = Convert.ToInt32(row.Cells[0].Value) * price3;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!cek)
            {
                dtBarang.Rows.Add(1, "Sandal", "Rp 50.000", price3);
            }
            totalPrices = totalPrice += (price3);
            tax = totalPrices / 10;
            tb_subtotal.Text = totalPrices.ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void bt_cicinsilver_Click(object sender, EventArgs e)
        {
            int tax;
            bool cek = false;

            foreach (DataGridViewRow row in dgv_item.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Cincin Silver")
                {
                    cek = true;
                    counter++;
                    int currentqty = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentqty + 1;
                    totals = Convert.ToInt32(row.Cells[0].Value) * price1;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!cek)
            {
                dtBarang.Rows.Add(1, "Cincin Silver", "Rp 20.000", price1);
            }
            totalPrices = totalPrice += (price1);
            tax = totalPrices / 10;
            tb_subtotal.Text = totalPrices.ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void bt_cicinemas_Click(object sender, EventArgs e)
        {
            int tax;
            bool cek = false;

            foreach (DataGridViewRow row in dgv_item.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Cincin Emas")
                {
                    cek = true;
                    counter++;
                    int currentqty = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentqty + 1;
                    totals = Convert.ToInt32(row.Cells[0].Value) * price2;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!cek)
            {
                dtBarang.Rows.Add(1, "Cincin Emas", "Rp 30.000", price2);
            }
            totalPrices = totalPrice += (price2);
            tax = totalPrices / 10;
            tb_subtotal.Text = totalPrices.ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void bt_kalungemas_Click(object sender, EventArgs e)
        {
            int tax;
            bool cek = false;

            foreach (DataGridViewRow row in dgv_item.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Kalung Emas")
                {
                    cek = true;
                    counter++;
                    int currentqty = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentqty + 1;
                    totals = Convert.ToInt32(row.Cells[0].Value) * price3;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!cek)
            {
                dtBarang.Rows.Add(1, "Kalung Emas", "Rp 50.000", price3);
            }
            totalPrices = totalPrice += (price3);
            tax = totalPrices / 10;
            tb_subtotal.Text = totalPrices.ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }
        //
        private void bt_kemejatosca_Click(object sender, EventArgs e)
        {
            int tax;
            bool cek = false;

            foreach (DataGridViewRow row in dgv_item.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Kemeja Tosca")
                {
                    cek = true;
                    counter++;
                    int currentqty = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentqty + 1;
                    totals = Convert.ToInt32(row.Cells[0].Value) * price3;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!cek)
            {
                dtBarang.Rows.Add(1, "Kemeja Tosca", "Rp 50.000", price3);
            }
            totalPrices = totalPrice += (price1);
            tax = totalPrices / 10;
            tb_subtotal.Text = totalPrices.ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void bt_kemejamerah_Click(object sender, EventArgs e)
        {
            int tax;
            bool cek = false;

            foreach (DataGridViewRow row in dgv_item.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Kemeja Merah")
                {
                    cek = true;
                    counter++;
                    int currentqty = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentqty + 1;
                    totals = Convert.ToInt32(row.Cells[0].Value) * price2;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!cek)
            {
                dtBarang.Rows.Add(1, "Kemeja Merah", "Rp 30.000", price2);
            }
            totalPrices = totalPrice += (price2);
            tax = totalPrices / 10;
            tb_subtotal.Text = totalPrices.ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void bt_kemejaabu_Click(object sender, EventArgs e)
        {
            int tax;
            bool cek = false;

            foreach (DataGridViewRow row in dgv_item.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Kemeja Abu")
                {
                    cek = true;
                    counter++;
                    int currentqty = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentqty + 1;
                    totals = Convert.ToInt32(row.Cells[0].Value) * price1;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!cek)
            {
                dtBarang.Rows.Add(1, "Kemeja Abu", "Rp 20.000", price1);
            }
            totalPrices = totalPrice += (price1);
            tax = totalPrices / 10;
            tb_subtotal.Text = totalPrices.ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }
        //
        private void bt_clanaCewe_Click(object sender, EventArgs e)
        {
            int tax;
            bool cek = false;

            foreach (DataGridViewRow row in dgv_item.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Celana Cewe")
                {
                    cek = true;
                    counter++;
                    int currentqty = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentqty + 1;
                    totals = Convert.ToInt32(row.Cells[0].Value) * price1;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!cek)
            {
                dtBarang.Rows.Add(1, "Celana Cewe", "Rp 20.000", price1);
            }
            totalPrices = totalPrice += (price1);
            tax = totalPrices / 10;
            tb_subtotal.Text = totalPrices.ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void bt_clnaCowo_Click(object sender, EventArgs e)
        {
            int tax;
            bool cek = false;

            foreach (DataGridViewRow row in dgv_item.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Celana Cowo")
                {
                    cek = true;
                    counter++;
                    int currentqty = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentqty + 1;
                    totals = Convert.ToInt32(row.Cells[0].Value) * price2;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!cek)
            {
                dtBarang.Rows.Add(1, "Celana Cowo", "Rp 30.000", price2);
            }
            totalPrices = totalPrice += (price2);
            tax = totalPrices / 10;
            tb_subtotal.Text = totalPrices.ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void bt_clanaAnak_Click(object sender, EventArgs e)
        {
            int tax;
            bool cek = false;

            foreach (DataGridViewRow row in dgv_item.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Celana Anak")
                {
                    cek = true;
                    counter++;
                    int currentqty = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentqty + 1;
                    totals = Convert.ToInt32(row.Cells[0].Value) * price3;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!cek)
            {
                dtBarang.Rows.Add(1, "Celana Anak", "Rp 50.000", price3);
            }
            totalPrices = totalPrice += (price1);
            tax = totalPrices / 10;
            tb_subtotal.Text = totalPrices.ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void bt_clanaAbu_Click(object sender, EventArgs e)
        {
            int tax;
            bool cek = false;

            foreach (DataGridViewRow row in dgv_item.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Celana Abu")
                {
                    cek = true;
                    counter++;
                    int currentqty = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentqty + 1;
                    totals = Convert.ToInt32(row.Cells[0].Value) * price1;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!cek)
            {
                dtBarang.Rows.Add(1, "Celana Abu", "Rp 20.000", price1);
            }
            totalPrices = totalPrice += (price1);
            tax = totalPrices / 10;
            tb_subtotal.Text = totalPrices.ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void bt_clanaCream_Click(object sender, EventArgs e)
        {
            int tax;
            bool cek = false;

            foreach (DataGridViewRow row in dgv_item.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Celana Cream")
                {
                    cek = true;
                    counter++;
                    int currentqty = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentqty + 1;
                    totals = Convert.ToInt32(row.Cells[0].Value) * price2;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!cek)
            {
                dtBarang.Rows.Add(1, "Celana Cream", "Rp 30.000", price2);
            }
            totalPrices = totalPrice += (price2);
            tax = totalPrices / 10;
            tb_subtotal.Text = totalPrices.ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void bt_ClanaMerah_Click(object sender, EventArgs e)
        {
            int tax;
            bool cek = false;

            foreach (DataGridViewRow row in dgv_item.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Celana Merah")
                {
                    cek = true;
                    counter++;
                    int currentqty = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentqty + 1;
                    totals = Convert.ToInt32(row.Cells[0].Value) * price3;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!cek)
            {
                dtBarang.Rows.Add(1, "Celana Merah", "Rp 50.000", price3);
            }
            totalPrices = totalPrice += (price1);
            tax = totalPrices / 10;
            tb_subtotal.Text = totalPrices.ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void bt_rainbow_Click(object sender, EventArgs e)
        {
            int tax;
            bool cek = false;

            foreach (DataGridViewRow row in dgv_item.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Rainbow")
                {
                    cek = true;
                    counter++;
                    int currentqty = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentqty + 1;
                    totals = Convert.ToInt32(row.Cells[0].Value) * price1;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!cek)
            {
                dtBarang.Rows.Add(1, "Rainbow", "Rp 20.000", price1);
            }
            totalPrices = totalPrice += (price1);
            tax = totalPrices / 10;
            tb_subtotal.Text = totalPrices.ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void bt_tanktop_Click(object sender, EventArgs e)
        {

            int tax;
            bool cek = false;

            foreach (DataGridViewRow row in dgv_item.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Tank Top")
                {
                    cek = true;
                    counter++;
                    int currentqty = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentqty + 1;
                    totals = Convert.ToInt32(row.Cells[0].Value) * price2;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!cek)
            {
                dtBarang.Rows.Add(1, "Tank Top", "Rp 30.000", price2);
            }
            totalPrices = totalPrice += (price2);
            tax = totalPrices / 10;
            tb_subtotal.Text = totalPrices.ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void bt_kaos_Click(object sender, EventArgs e)
        {
            int tax;
            bool cek = false;

            foreach (DataGridViewRow row in dgv_item.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == "Kaos")
                {
                    cek = true;
                    counter++;
                    int currentqty = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentqty + 1;
                    totals = Convert.ToInt32(row.Cells[0].Value) * price3;
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!cek)
            {
                dtBarang.Rows.Add(1, "Kaos", "Rp 50.000", price3);
            }
            totalPrices = totalPrice += (price1);
            tax = totalPrices / 10;
            tb_subtotal.Text = totalPrices.ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void bt_Add_Click(object sender, EventArgs e)
        {
            int tax;
            bool cek = false;

            foreach (DataGridViewRow row in dgv_item.Rows)
            {
                if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() == tb_ItemName.Text)
                {
                    cek = true;
                    counter++;
                    int currentqty = Convert.ToInt32(row.Cells[0].Value);
                    row.Cells[0].Value = currentqty + 1;
                    totals = Convert.ToInt32(row.Cells[0].Value) * Convert.ToInt32(tb_ItemPrice.Text);
                    row.Cells[3].Value = totals;
                    break;
                }
            }
            if (!cek)
            {
                dtBarang.Rows.Add(1, tb_ItemName.Text, tb_ItemPrice.Text, Convert.ToInt32(tb_ItemPrice.Text));
            }
            totalPrices = totalPrice += (Convert.ToInt32(tb_ItemPrice.Text));
            tax = totalPrices / 10;
            tb_subtotal.Text = totalPrices.ToString();
            tb_total.Text = (totalPrices + tax).ToString();
        }

        private void bt_Upload_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image Files (*.jpg, *.png, *.bmp)|*.jpg; *.png; *.bmp|All Files(.)|*.*";
            ofd.Multiselect = true;
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pictureBox.Image = Image.FromFile(ofd.FileName);
                tb_ItemName.Enabled = true;
                tb_ItemPrice.Enabled = true;
            }
        }

        private void bt_Delete_Click(object sender, EventArgs e)
        {
            if (index >= 0 )
            {
                dtBarang.Rows.RemoveAt(index);

            }
            int tes = 0;
            for (int i = 0; i < dtBarang.Rows.Count; i++)
            {
                tes = Convert.ToInt32(dtBarang.Rows[i][3]);
            }
           // tb_subtotal.Text += tes.ToString();
            tb_subtotal.Text = tes.ToString();
            tb_total.Text = (tes + tes /10).ToString();
            totalPrice = tes;
        }

        private void tb_ItemPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}